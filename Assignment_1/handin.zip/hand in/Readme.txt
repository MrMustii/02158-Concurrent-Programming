The follwoing files are
-Search.java : the program used for the problems
- ProbX: result of the execution of the program where 
		Prob1 : runs time
		Prob2: tasks speedup
		prob3: tasks speedup for up to 250 with 10-task steps
		prob3zoom : tasks speedup for 3 tasks
		prob4fixedthreads: tasks speedup 
		prob4fixedtasks: threads speedup (still shows tasks but the step size is 2 and the start value is 2)
-gbar: using HPC machine where
		gbarprob3: tasks speedup
		gbarprob4fixedtasks: threads speedup (still shows tasks but the step size is 1 and the start value is 1)
		gbarprob4fixedthreads: tasks speedup

pattern: "xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|vvvvvvvvxxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|vxxxxxxxxx|xxxxxxxxx|vvvvvvxxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxx|xxxxxxxxxx|"